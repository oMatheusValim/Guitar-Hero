CMakeFiles/GuitarHero.dir/src/note_manager.cpp.obj: \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/src/note_manager.cpp \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/include/note_manager.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/vector \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_algobase.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/c++config.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/os_defines.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/cpu_defines.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/pstl/pstl_config.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/functexcept.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/exception_defines.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/cpp_type_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ext/type_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ext/numeric_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_pair.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/type_traits \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/move.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/utility.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_iterator_base_types.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_iterator_base_funcs.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/concept_check.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/debug/assertions.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_iterator.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/ptr_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/debug/debug.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/predefined_ops.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/allocator.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/c++allocator.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/new_allocator.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/new \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/exception.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/memoryfwd.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_construct.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_uninitialized.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ext/alloc_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/alloc_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_vector.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/initializer_list \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_bvector.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/functional_hash.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/hash_bytes.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/refwrap.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/invoke.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stl_function.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/backward/binders.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/range_access.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/vector.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/string \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/stringfwd.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/char_traits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/postypes.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cwchar \
 /usr/share/mingw-w64/include/wchar.h \
 /usr/share/mingw-w64/include/corecrt.h \
 /usr/share/mingw-w64/include/_mingw.h \
 /usr/share/mingw-w64/include/_mingw_mac.h \
 /usr/share/mingw-w64/include/_mingw_secapi.h \
 /usr/share/mingw-w64/include/vadefs.h \
 /usr/share/mingw-w64/include/sdks/_mingw_ddk.h \
 /usr/share/mingw-w64/include/corecrt_stdio_config.h \
 /usr/share/mingw-w64/include/corecrt_wstdlib.h \
 /usr/share/mingw-w64/include/_mingw_off_t.h \
 /usr/share/mingw-w64/include/_mingw_stat64.h \
 /usr/share/mingw-w64/include/swprintf.inl \
 /usr/share/mingw-w64/include/sec_api/wchar_s.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cstdint \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/stdint.h \
 /usr/share/mingw-w64/include/stdint.h \
 /usr/share/mingw-w64/include/crtdefs.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/stddef.h \
 /usr/share/mingw-w64/include/stddef.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/localefwd.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/c++locale.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/clocale \
 /usr/share/mingw-w64/include/locale.h \
 /usr/share/mingw-w64/include/stdio.h \
 /usr/share/mingw-w64/include/sec_api/stdio_s.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/iosfwd \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cctype \
 /usr/share/mingw-w64/include/ctype.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/ostream_insert.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/cxxabi_forced.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/basic_string.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/string_view \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/string_view.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ext/string_conversions.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cstdlib \
 /usr/share/mingw-w64/include/stdlib.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include-fixed/limits.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include-fixed/syslimits.h \
 /usr/share/mingw-w64/include/limits.h \
 /usr/share/mingw-w64/include/sec_api/stdlib_s.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/stdlib.h \
 /usr/share/mingw-w64/include/malloc.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/mm_malloc.h \
 /usr/share/mingw-w64/include/errno.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/std_abs.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cstdio \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cerrno \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/charconv.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/basic_string.tcc \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/allegro5.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/allegro.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/base.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/stdarg.h \
 /usr/share/mingw-w64/include/stdarg.h \
 /usr/share/mingw-w64/include/_mingw_stdarg.h \
 /usr/share/mingw-w64/include/time.h \
 /usr/share/mingw-w64/include/sys/timeb.h \
 /usr/share/mingw-w64/include/sec_api/sys/timeb_s.h \
 /usr/share/mingw-w64/include/_timeval.h \
 /usr/share/mingw-w64/include/pthread_time.h \
 /usr/share/mingw-w64/include/string.h \
 /usr/share/mingw-w64/include/sec_api/string_s.h \
 /usr/share/mingw-w64/include/sys/types.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/internal/alconfig.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/platform/alplatf.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/platform/almngw32.h \
 /usr/share/mingw-w64/include/io.h /usr/share/mingw-w64/include/fcntl.h \
 /usr/share/mingw-w64/include/direct.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/platform/astdint.h \
 /usr/share/mingw-w64/include/inttypes.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/platform/astdbool.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/altime.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/bitmap.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/color.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/bitmap_draw.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/bitmap_io.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/file.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/path.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/utf8.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/bitmap_lock.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/blender.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/clipboard.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/display.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/events.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/config.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/cpu.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/debug.h \
 /usr/share/mingw-w64/include/assert.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/drawing.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/error.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/fixed.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/fmaths.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/inline/fmaths.inl \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/fshook.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/fullscreen_mode.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/haptic.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/joystick.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/keyboard.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/keycodes.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/mouse.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/touch_input.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/memory.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/monitor.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/mouse_cursor.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/render_state.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/shader.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/transformations.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/system.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/threads.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/timer.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/tls.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/alcompat.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/platform/alwin.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/fstream \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/istream \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ios \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/exception \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/exception_ptr.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/cxxabi_init_exception.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/typeinfo \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/nested_exception.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/ios_base.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ext/atomicity.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/gthr.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/gthr-default.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/atomic_word.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/locale_classes.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/locale_classes.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/system_error \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/error_constants.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/stdexcept \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/streambuf \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/streambuf.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/basic_ios.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/locale_facets.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/cwctype \
 /usr/share/mingw-w64/include/wctype.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/ctype_base.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/streambuf_iterator.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/ctype_inline.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/locale_facets.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/basic_ios.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/ostream \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/ostream.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/istream.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/codecvt.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/basic_file.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/x86_64-w64-mingw32/bits/c++io.h \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/fstream.tcc \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/iostream \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/sstream \
 /usr/lib/gcc/x86_64-w64-mingw32/12-win32/include/c++/bits/sstream.tcc \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/allegro_primitives.h \
 /home/mvalim/Área\ de\ trabalho/GitHub/Guitar-Hero/Guitar\ Hero/allegro/include/allegro5/allegro.h
